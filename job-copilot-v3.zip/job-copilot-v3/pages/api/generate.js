// POST /api/generate
// Server-side only – API key never exposed to client
// Future: add NextAuth session check + Stripe plan verification here

import Anthropic from '@anthropic-ai/sdk';

// Input sanitizer
function sanitize(str) {
  if (typeof str !== 'string') return '';
  return str
    .replace(/<[^>]*>/g, '')          // strip HTML tags
    .replace(/[^\w\s\-.,;:!?@()/\n\r\t€$%°üöäÜÖÄß]/g, ' ')
    .trim()
    .slice(0, 3000);                   // hard cap per field
}

// Detect if text is predominantly German
function isGerman(text) {
  const germanWords = /\b(die|der|das|und|in|zu|von|mit|für|auf|ist|ich|sie|wir|nicht|ein|eine|haben|werden|als|Stelle|Bewerbung|Kenntnisse|Erfahrung|Unternehmen|Jahre|Team|Aufgaben|Anforderungen|Profil|Wir|Ihr|sind|suchen|bieten|freuen)\b/gi;
  const matches = text.match(germanWords) || [];
  return matches.length >= 4;
}

function buildPrompt(jobOffer, cv, lang) {
  const langInstruction = lang === 'de'
    ? 'Antworte AUSSCHLIESSLICH auf Deutsch. Verwende einen direkten, menschlichen Ton ohne Unternehmensfloskeln.'
    : 'Reply in English. Use a direct, human tone. No corporate buzzwords.';

  return `${langInstruction}

Analyze this job offer and CV, then return ONLY a valid JSON object (no markdown, no explanation, no code fences) with this exact structure:

{
  "matchScore": <integer 0-100>,
  "strengths": [<3-5 short bullet strings in target language>],
  "gaps": [<2-4 short bullet strings in target language>],
  "tips": [<3-5 short actionable bullet strings in target language>],
  "optimizedCV": "<full rewritten CV as plain text, tailored to this job, max 600 words>",
  "coverLetter": "<max 6 lines cover letter, direct tone, no 'Sehr geehrte Damen und Herren' cliché>",
  "interviewQA": [
    {"question": "<question>", "answer": "<personalized answer based on CV, 2-3 sentences max>"},
    {"question": "<question>", "answer": "<answer>"},
    {"question": "<question>", "answer": "<answer>"},
    {"question": "<question>", "answer": "<answer>"},
    {"question": "<question>", "answer": "<answer>"}
  ]
}

Rules:
- matchScore reflects real fit between CV and job requirements
- optimizedCV: keep real facts, improve presentation and keyword alignment
- coverLetter: max 6 lines, human, specific to this role
- interviewQA: realistic questions an interviewer would ask for THIS role
- No generic phrases. No empty compliments. Be brutally useful.

---JOB OFFER---
${jobOffer}

---CV---
${cv}`;
}

// Mock response for development / when no API key is set
function mockResponse(lang) {
  const de = lang === 'de';
  return {
    matchScore: 74,
    strengths: de
      ? ['Technische Kenntnisse passen zur Stelle', 'Relevante Berufserfahrung vorhanden', 'Nachweisbare Projekterfolge']
      : ['Technical skills match the role', 'Relevant work experience', 'Proven project results'],
    gaps: de
      ? ['Fehlende Zertifizierung erwähnt', 'Branchenkenntnisse könnten tiefer sein']
      : ['Missing mentioned certification', 'Industry knowledge could be deeper'],
    tips: de
      ? ['Quantifiziere deine Erfolge mit Zahlen', 'Erwähne die Tools aus der Stellenausschreibung direkt', 'Schreib die Zusammenfassung jobbezogen um']
      : ['Quantify achievements with numbers', 'Mention tools from the job posting directly', 'Rewrite summary to be job-specific'],
    optimizedCV: de
      ? `Max Mustermann\nmax@email.de | +49 123 456789 | LinkedIn\n\nPROFIL\nErfahrener Software-Entwickler mit 5 Jahren Erfahrung in der Entwicklung skalierbarer Webanwendungen. Spezialisiert auf React, Node.js und Cloud-Architekturen.\n\nBERUFSERFAHRUNG\n\nSenior Developer – TechGmbH (2020–heute)\n• Entwicklung von Microservices, die die Ladezeiten um 40% verbessert haben\n• Leitung eines 4-köpfigen Teams bei der Migration zu AWS\n• Implementierung von CI/CD-Pipelines, die die Deployment-Zeit halbiert haben\n\nDeveloper – StartupAG (2018–2020)\n• Aufbau der Frontend-Architektur von Grund auf\n• Integration von Zahlungsanbietern (Stripe, PayPal)\n\nAUSBILDUNG\nB.Sc. Informatik – TU München (2018)\n\nKENNTNISSE\nReact, TypeScript, Node.js, PostgreSQL, AWS, Docker, Git`
      : `Jane Doe\njane@email.com | +1 555 0100 | LinkedIn\n\nPROFILE\nExperienced software developer with 5 years building scalable web applications. Specialized in React, Node.js, and cloud architectures.\n\nEXPERIENCE\n\nSenior Developer – TechCorp (2020–present)\n• Built microservices reducing load times by 40%\n• Led 4-person team migrating infrastructure to AWS\n• Implemented CI/CD pipelines cutting deploy time in half\n\nDeveloper – StartupInc (2018–2020)\n• Built frontend architecture from scratch\n• Integrated payment providers (Stripe, PayPal)\n\nEDUCATION\nB.Sc. Computer Science – MIT (2018)\n\nSKILLS\nReact, TypeScript, Node.js, PostgreSQL, AWS, Docker, Git`,
    coverLetter: de
      ? `Hallo,\n\nich bewerbe mich auf die ausgeschriebene Stelle, weil sie genau zu meinem Hintergrund passt: fünf Jahre Erfahrung in der Webentwicklung, davon zwei als Tech Lead.\n\nBei TechGmbH habe ich Systeme gebaut, die täglich von über 50.000 Nutzern verwendet werden. Ich arbeite pragmatisch, liefere pünktlich und kommuniziere klar.\n\nIch freue mich auf ein Gespräch.\n\nMax Mustermann`
      : `Hi,\n\nI'm applying because this role aligns directly with my background: five years in web development, two of them as tech lead.\n\nAt TechCorp I built systems used by 50,000+ users daily. I work pragmatically, deliver on time, and communicate clearly.\n\nLooking forward to talking.\n\nJane Doe`,
    interviewQA: de
      ? [
          { question: 'Beschreibe ein technisches Problem, das du eigenständig gelöst hast.', answer: 'Bei TechGmbH hatte unser Hauptdienst eine hohe Latenz unter Last. Ich analysierte die Datenbankabfragen, optimierte die Indizes und reduzierte die Antwortzeit um 60% innerhalb einer Woche.' },
          { question: 'Wie gehst du mit Konflikten im Team um?', answer: 'Ich suche das direkte Gespräch, höre zu und fokussiere mich auf die Sachlage statt auf Personen. In meinem letzten Team haben wir dadurch einen Architekturstreit schnell lösen können.' },
          { question: 'Warum wechselst du die Stelle?', answer: 'Ich suche ein Umfeld mit mehr technischer Tiefe und der Möglichkeit, Architekturentscheidungen mitzugestalten. Diese Stelle bietet genau das.' },
          { question: 'Was weißt du über unser Unternehmen?', answer: 'Ich habe eure Produktarchitektur analysiert und finde den Ansatz mit Microservices und der starken API-First-Strategie überzeugend. Das entspricht genau meinem Arbeitsstil.' },
          { question: 'Wo siehst du dich in 3 Jahren?', answer: 'Als technische Führungskraft, die nicht nur Code schreibt, sondern das Team wachsen sieht und zur Produktstrategie beiträgt.' }
        ]
      : [
          { question: 'Describe a technical problem you solved independently.', answer: 'At TechCorp our main service had high latency under load. I analyzed query patterns, optimized indexes, and cut response time by 60% within a week.' },
          { question: 'How do you handle team conflicts?', answer: 'I address things directly, listen first, and focus on the issue not the person. We resolved a major architecture disagreement this way in my last team.' },
          { question: 'Why are you leaving your current role?', answer: 'I want an environment with deeper technical challenges and more ownership over architecture decisions. This role offers exactly that.' },
          { question: 'What do you know about our company?', answer: 'I looked at your product architecture and find the API-first, microservices approach compelling. That aligns well with how I like to build.' },
          { question: 'Where do you see yourself in 3 years?', answer: 'In a technical leadership role where I\'m not just writing code but helping the team grow and contributing to product strategy.' }
        ]
  };
}

export default async function handler(req, res) {
  // Security: only POST
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Rate limiting hint (real rate limiting should be done at CDN/middleware level)
  // Future: verify NextAuth session + Stripe subscription here
  
  try {
    const { jobOffer: rawJob, cv: rawCV } = req.body;

    // Validate presence
    if (!rawJob || !rawCV) {
      return res.status(400).json({ error: 'Missing jobOffer or cv in request body' });
    }

    // Sanitize inputs
    const jobOffer = sanitize(rawJob);
    const cv = sanitize(rawCV);

    if (jobOffer.length < 50 || cv.length < 50) {
      return res.status(400).json({ error: 'Input too short. Please provide complete job offer and CV.' });
    }

    const lang = isGerman(jobOffer) ? 'de' : 'en';

    // If no API key, return mock data (development / demo mode)
    if (!process.env.ANTHROPIC_API_KEY) {
      await new Promise(r => setTimeout(r, 1800)); // simulate latency
      return res.status(200).json({ ...mockResponse(lang), mock: true, lang });
    }

    // Real Anthropic call
    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

    const message = await client.messages.create({
      model: 'claude-sonnet-4-5',
      max_tokens: 4096,
      messages: [
        { role: 'user', content: buildPrompt(jobOffer, cv, lang) }
      ]
    });

    const raw = message.content[0]?.text || '';
    
    // Parse JSON safely
    let parsed;
    try {
      // Strip possible markdown fences
      const cleaned = raw.replace(/^```json\s*/i, '').replace(/\s*```$/i, '').trim();
      parsed = JSON.parse(cleaned);
    } catch {
      console.error('[/api/generate] JSON parse error. Raw output:', raw.slice(0, 500));
      return res.status(500).json({ error: 'AI returned invalid JSON. Please try again.' });
    }

    return res.status(200).json({ ...parsed, mock: false, lang });

  } catch (err) {
    // Log detailed error for debugging
    console.error('[/api/generate] Error:', err?.message || err);
    console.error('[/api/generate] Status:', err?.status);
    console.error('[/api/generate] Type:', err?.error?.type);

    // Return specific error messages
    if (err?.status === 401) {
      return res.status(500).json({ error: 'API Key inválida o no autorizada. Verifica tu ANTHROPIC_API_KEY en .env.local' });
    }
    if (err?.status === 429) {
      return res.status(500).json({ error: 'Límite de la API alcanzado. Espera un momento e inténtalo de nuevo.' });
    }
    if (err?.status === 400 && err?.message?.includes('credit')) {
      return res.status(500).json({ error: 'Sin créditos en Anthropic. Ve a console.anthropic.com → Plans & Billing para recargar.' });
    }
    if (err?.status === 400) {
      return res.status(500).json({ error: 'Solicitud inválida a la IA. Intenta con menos texto.' });
    }
    return res.status(500).json({ error: `Error interno: ${err?.message || 'desconocido'}. Revisa la consola del servidor.` });
  }
}
