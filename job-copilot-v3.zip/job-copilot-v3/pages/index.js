import { useState, useRef } from 'react';
import Head from 'next/head';
import { useUsageLimit } from '../lib/useUsageLimit';
import LoadingOverlay from '../components/LoadingOverlay';
import MatchScore from '../components/MatchScore';
import EditableSection from '../components/EditableSection';
import ProModal from '../components/ProModal';
import Footer from '../components/Footer';

const MAX_INPUT = 3000;

function CharCount({ value, max }) {
  const pct = value.length / max;
  const color = pct > 0.9 ? 'var(--red)' : pct > 0.7 ? 'var(--amber)' : 'var(--text-dim)';
  return (
    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color }}>
      {value.length}/{max}
    </span>
  );
}

export default function Home() {
  const [jobOffer, setJobOffer] = useState('');
  const [cv, setCv] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPro, setShowPro] = useState(false);
  const [lang, setLang] = useState('de');

  // Editable state
  const [editCV, setEditCV] = useState('');
  const [editCover, setEditCover] = useState('');
  const [editQA, setEditQA] = useState([]);

  const { remaining, limitReached, incrementUsage, loaded, FREE_LIMIT } = useUsageLimit();
  const resultsRef = useRef(null);

  async function handleGenerate() {
    if (!jobOffer.trim() || !cv.trim()) {
      setError('Bitte gib sowohl das Stellenangebot als auch deinen Lebenslauf ein.');
      return;
    }
    if (limitReached) {
      setShowPro(true);
      return;
    }

    setError('');
    setLoading(true);

    const count = incrementUsage();
    if (count > FREE_LIMIT) {
      setLoading(false);
      setShowPro(true);
      return;
    }

    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jobOffer, cv }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Fehler beim Generieren. Bitte versuche es erneut.');
        setLoading(false);
        return;
      }

      setResult(data);
      setEditCV(data.optimizedCV || '');
      setEditCover(data.coverLetter || '');
      setEditQA(data.interviewQA || []);
      setLang(data.lang || 'de');

      setLoading(false);

      setTimeout(() => {
        resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);

    } catch {
      setError('Netzwerkfehler. Überprüfe deine Verbindung.');
      setLoading(false);
    }
  }

  async function handleSectionRegenerate(section) {
    if (!result) return;
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jobOffer, cv }),
      });
      const data = await res.json();
      if (!res.ok) return;
      if (section === 'cv') setEditCV(data.optimizedCV || '');
      if (section === 'cover') setEditCover(data.coverLetter || '');
      if (section === 'qa') setEditQA(data.interviewQA || []);
    } catch { /* silent */ }
  }

  async function handleSimplify(section) {
    const text = section === 'cv' ? editCV : editCover;
    if (!text) return;
    // Simple client-side simplification: trim to first 70% of lines
    const lines = text.split('\n');
    const shorter = lines.slice(0, Math.max(3, Math.ceil(lines.length * 0.7))).join('\n');
    if (section === 'cv') setEditCV(shorter);
    if (section === 'cover') setEditCover(shorter);
  }

  const isReady = jobOffer.trim().length >= 50 && cv.trim().length >= 50;

  return (
    <>
      <Head>
        <title>Job Copilot v3 – KI-Bewerbungsoptimierung</title>
        <meta name="description" content="KI-gestütztes Tool zur Bewerbungsoptimierung: CV, Anschreiben, Interview-Fragen und Match Score – in Sekunden." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta property="og:title" content="Job Copilot v3" />
        <meta property="og:description" content="CV optimieren, Anschreiben generieren, Interviewfragen mit persönlichen Antworten." />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <LoadingOverlay active={loading} lang={lang} />
      <ProModal open={showPro} onClose={() => setShowPro(false)} lang={lang} />

      <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>

        {/* Header */}
        <header style={{
          borderBottom: '1px solid var(--border)',
          background: 'var(--bg-1)',
          position: 'sticky', top: 0, zIndex: 100,
          backdropFilter: 'blur(12px)',
        }}>
          <div style={{
            maxWidth: 900, margin: '0 auto', padding: '0 24px',
            height: 56, display: 'flex', alignItems: 'center',
            justifyContent: 'space-between',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 20 }}>⚡</span>
              <span style={{
                fontWeight: 800, fontSize: 17, letterSpacing: '-0.02em',
                background: 'linear-gradient(90deg, var(--text), var(--green))',
                WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
              }}>Job Copilot</span>
              <span style={{
                fontFamily: 'var(--font-mono)', fontSize: 10,
                color: 'var(--green)', background: 'var(--green-bg)',
                border: '1px solid var(--green)33',
                padding: '2px 6px', borderRadius: 3,
              }}>v3</span>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
              {loaded && (
                <div style={{
                  fontFamily: 'var(--font-mono)', fontSize: 11,
                  color: remaining === 0 ? 'var(--red)' : remaining === 1 ? 'var(--amber)' : 'var(--text-dim)',
                  display: 'flex', alignItems: 'center', gap: 6,
                }}>
                  {[...Array(FREE_LIMIT)].map((_, i) => (
                    <span key={i} style={{
                      width: 6, height: 6, borderRadius: '50%',
                      background: i < (FREE_LIMIT - remaining) ? 'var(--text-dim)' : 'var(--green)',
                      display: 'block',
                    }} />
                  ))}
                  <span>{remaining} / {FREE_LIMIT}</span>
                </div>
              )}
              <button
                onClick={() => setShowPro(true)}
                style={{
                  fontFamily: 'var(--font-mono)', fontSize: 11,
                  padding: '5px 12px', borderRadius: 5,
                  border: '1px solid var(--green)44',
                  background: 'var(--green-bg)',
                  color: 'var(--green)', cursor: 'pointer',
                  transition: 'all 0.15s ease',
                }}
                onMouseEnter={e => { e.currentTarget.style.background = 'var(--green)'; e.currentTarget.style.color = 'var(--bg)'; }}
                onMouseLeave={e => { e.currentTarget.style.background = 'var(--green-bg)'; e.currentTarget.style.color = 'var(--green)'; }}
              >
                PRO ↗
              </button>
            </div>
          </div>
        </header>

        <main style={{ flex: 1, maxWidth: 900, margin: '0 auto', padding: '40px 24px', width: '100%' }}>

          {/* Hero */}
          <div style={{ textAlign: 'center', marginBottom: 48, animation: 'slideUp 0.5s ease' }}>
            <div style={{
              fontFamily: 'var(--font-mono)', fontSize: 11,
              color: 'var(--green)', letterSpacing: '0.15em',
              textTransform: 'uppercase', marginBottom: 14,
            }}>
              KI-BEWERBUNGSOPTIMIERUNG
            </div>
            <h1 style={{
              fontSize: 'clamp(28px, 5vw, 46px)', fontWeight: 800,
              letterSpacing: '-0.03em', lineHeight: 1.1, marginBottom: 14,
            }}>
              Stell dich besser vor.<br />
              <span style={{
                background: 'linear-gradient(90deg, var(--green), var(--green-dim))',
                WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
              }}>In Sekunden.</span>
            </h1>
            <p style={{ fontSize: 15, color: 'var(--text-muted)', maxWidth: 520, margin: '0 auto' }}>
              Füge Stellenangebot und Lebenslauf ein – Job Copilot optimiert deinen CV,
              schreibt ein Anschreiben und bereitet dich auf das Interview vor.
            </p>
          </div>

          {/* Input grid */}
          <div style={{
            display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16,
            marginBottom: 20,
          }} className="input-grid">
            {/* Job offer */}
            <div>
              <div style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                marginBottom: 8,
              }}>
                <label style={{
                  fontFamily: 'var(--font-mono)', fontSize: 11,
                  color: 'var(--text-muted)', letterSpacing: '0.08em', textTransform: 'uppercase',
                }}>
                  📋 Stellenangebot
                </label>
                <CharCount value={jobOffer} max={MAX_INPUT} />
              </div>
              <textarea
                value={jobOffer}
                onChange={e => setJobOffer(e.target.value.slice(0, MAX_INPUT))}
                placeholder="Füge hier die vollständige Stellenbeschreibung ein…"
                style={{
                  width: '100%', minHeight: 260,
                  background: 'var(--bg-2)', border: '1px solid var(--border)',
                  borderRadius: 'var(--radius-lg)', color: 'var(--text)',
                  fontFamily: 'var(--font-mono)', fontSize: 13,
                  padding: '14px 16px', resize: 'vertical', outline: 'none',
                  lineHeight: 1.6, transition: 'border-color 0.15s',
                }}
                onFocus={e => e.target.style.borderColor = 'var(--green)44'}
                onBlur={e => e.target.style.borderColor = 'var(--border)'}
              />
            </div>

            {/* CV */}
            <div>
              <div style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                marginBottom: 8,
              }}>
                <label style={{
                  fontFamily: 'var(--font-mono)', fontSize: 11,
                  color: 'var(--text-muted)', letterSpacing: '0.08em', textTransform: 'uppercase',
                }}>
                  📄 Lebenslauf
                </label>
                <CharCount value={cv} max={MAX_INPUT} />
              </div>
              <textarea
                value={cv}
                onChange={e => setCv(e.target.value.slice(0, MAX_INPUT))}
                placeholder="Füge hier deinen aktuellen Lebenslauf (als Text) ein…"
                style={{
                  width: '100%', minHeight: 260,
                  background: 'var(--bg-2)', border: '1px solid var(--border)',
                  borderRadius: 'var(--radius-lg)', color: 'var(--text)',
                  fontFamily: 'var(--font-mono)', fontSize: 13,
                  padding: '14px 16px', resize: 'vertical', outline: 'none',
                  lineHeight: 1.6, transition: 'border-color 0.15s',
                }}
                onFocus={e => e.target.style.borderColor = 'var(--green)44'}
                onBlur={e => e.target.style.borderColor = 'var(--border)'}
              />
            </div>
          </div>

          {/* Error */}
          {error && (
            <div style={{
              background: 'var(--red-bg)', border: '1px solid var(--red)33',
              borderRadius: 'var(--radius)', padding: '12px 16px',
              color: 'var(--red)', fontFamily: 'var(--font-mono)', fontSize: 13,
              marginBottom: 16, animation: 'fadeIn 0.3s ease',
            }}>
              ⚠ {error}
            </div>
          )}

          {/* CTA */}
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 56 }}>
            <button
              onClick={handleGenerate}
              disabled={!isReady || loading}
              style={{
                padding: '14px 36px',
                background: isReady && !loading ? 'var(--green)' : 'var(--bg-3)',
                border: `1px solid ${isReady && !loading ? 'var(--green)' : 'var(--border)'}`,
                borderRadius: 'var(--radius)',
                color: isReady && !loading ? 'var(--bg)' : 'var(--text-dim)',
                fontFamily: 'var(--font-sans)', fontSize: 15, fontWeight: 700,
                cursor: isReady && !loading ? 'pointer' : 'not-allowed',
                transition: 'all 0.2s ease',
                letterSpacing: '-0.01em',
                animation: isReady && !loading ? 'glow 2s ease infinite' : 'none',
              }}
              onMouseEnter={e => { if (isReady && !loading) e.currentTarget.style.transform = 'translateY(-1px)'; }}
              onMouseLeave={e => { e.currentTarget.style.transform = 'none'; }}
            >
              {loading ? '↻ Analysiere…' : '⚡ Bewerbung analysieren'}
            </button>
          </div>

          {/* Results */}
          {result && (
            <div ref={resultsRef} style={{ animation: 'slideUp 0.4s ease' }}>
              <div style={{
                display: 'flex', alignItems: 'center', gap: 12,
                marginBottom: 28,
              }}>
                <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
                <span style={{
                  fontFamily: 'var(--font-mono)', fontSize: 11,
                  color: 'var(--text-dim)', letterSpacing: '0.1em',
                  textTransform: 'uppercase',
                }}>
                  Analyse abgeschlossen
                  {result.mock && (
                    <span style={{ color: 'var(--amber)', marginLeft: 8 }}>
                      [Demo-Modus – API Key fehlt]
                    </span>
                  )}
                </span>
                <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
              </div>

              {/* Match Score */}
              <div style={{
                background: 'var(--bg-2)', border: '1px solid var(--border)',
                borderRadius: 'var(--radius-lg)', padding: '24px',
                marginBottom: 16,
              }}>
                <MatchScore
                  score={result.matchScore}
                  strengths={result.strengths}
                  gaps={result.gaps}
                  tips={result.tips}
                  lang={lang}
                />
              </div>

              {/* Optimized CV */}
              <div style={{ marginBottom: 16 }}>
                <EditableSection
                  title={lang === 'de' ? 'Optimierter Lebenslauf' : 'Optimized CV'}
                  icon="📄"
                  content={editCV}
                  onContentChange={setEditCV}
                  onRegenerate={() => handleSectionRegenerate('cv')}
                  onSimplify={() => handleSimplify('cv')}
                  lang={lang}
                />
              </div>

              {/* Cover Letter */}
              <div style={{ marginBottom: 16 }}>
                <EditableSection
                  title={lang === 'de' ? 'Anschreiben' : 'Cover Letter'}
                  icon="✉️"
                  content={editCover}
                  onContentChange={setEditCover}
                  onRegenerate={() => handleSectionRegenerate('cover')}
                  onSimplify={() => handleSimplify('cover')}
                  lang={lang}
                />
              </div>

              {/* Interview Q&A */}
              <EditableSection
                title={lang === 'de' ? '5 Interviewfragen mit Antworten' : '5 Interview Q&A'}
                icon="🎯"
                content={editQA}
                onContentChange={setEditQA}
                onRegenerate={() => handleSectionRegenerate('qa')}
                lang={lang}
                isQA
              />

              {/* Reset */}
              <div style={{ textAlign: 'center', marginTop: 32 }}>
                <button
                  onClick={() => {
                    setResult(null);
                    setJobOffer('');
                    setCv('');
                    setError('');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  style={{
                    fontFamily: 'var(--font-mono)', fontSize: 12,
                    padding: '8px 20px', borderRadius: 5,
                    border: '1px solid var(--border)',
                    background: 'transparent', color: 'var(--text-muted)',
                    cursor: 'pointer', transition: 'all 0.15s',
                  }}
                  onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--text-muted)'}
                  onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
                >
                  ↩ Neue Analyse
                </button>
              </div>
            </div>
          )}
        </main>

        <Footer />
      </div>

      <style>{`
        @media (max-width: 640px) {
          .input-grid {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </>
  );
}
